import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt(),a[] = new int[n];
        for(int i = 0;i<n;i++){
            a[i] = ps.nextInt();
            int sum = 0;
            for(int j = 1;j<=a[i];j++){
                sum+=j;
            }
            for(int  k = 0;k<a[i];k++){
                for(int p = k;p<a[i];p++){
                    System.out.print(sum+" ");
                    sum--;
                }
                System.out.println();
            }
        }
    }
}