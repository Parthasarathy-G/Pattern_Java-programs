import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        char ch = 'A';
        int c = 1,z=1;
        for(int i = 0;i<n;i++){
        System.out.print(" ");
        c = 1;
        char ca ='A';
        for(int l = 1;l<n-i;l++){
        System.out.print("  ");
        }
            for(int j = 0;j<=i;j++){
            System.out.print(" "+ca);
            ca++;
            }
            System.out.print(" ");
        for(int k = 0;k<=i;k++){
            System.out.print(c+" ");
            c++;
            }
        ch++;
        if(i>0)
        ch = ca;
        System.out.println();
        }
        int num =1;
        for(int i = 0;i<n;i++){
        System.out.print(" ");
        for(int k = 0;k<i;k++){
        System.out.print("  ");
        }
        for(int j = n;j>i;j--){
            System.out.print(" *");
        }
System.out.print(" ");
for(int k = i;k<n;k++){
            System.out.print(z+" ");
        z++;}
        System.out.println();
        }
    }
}


