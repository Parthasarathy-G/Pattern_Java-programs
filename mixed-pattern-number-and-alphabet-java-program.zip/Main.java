import java.util.*;
public class Main{
public static void main(String args[]){
Scanner pk = new Scanner(System.in);
int n = pk.nextInt(),p = 1;
char ch = 'a';
for(int i = 0;i<n;i++){
    for(int j =0;j<n;j++){
        if(i==j){
            System.out.print(p+" ");
        }
        else{
            System.out.print(ch+" ");
        }
   p++;
    ch++; }
    System.out.println();
}
    
}
}