import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt();
        char ch = 'A';
        int c = 1;
        for(int i = 0;i<n;i++){
        char ca ='A';
        for(int l = 1;l<n-i;l++){
        System.out.print(" ");
        }
            for(int j = 0;j<=i;j++){
            System.out.print("*");
            }
            System.out.print(" ");
        for(int k = 0;k<=i;k++){
            System.out.print(ch);
            if(k==1){
            ca = ch;
            }
        ch++;}
        if(i>0)
        ch = ca;
        System.out.println();
        }
        int num =1;
        for(int i = 0;i<n;i++){
        for(int k = 0;k<i;k++){
        System.out.print(" ");
        }
        for(int j = n;j>i;j--){
            System.out.print(j);
        }
System.out.print(" ");
for(int k = i;k<n;k++){
            System.out.print(c);
            if(k==i+1){
            num = c;
            }
        c+=2;}
        if(i!=n-1)
        c = num;
        System.out.println();
        }
    }
}
