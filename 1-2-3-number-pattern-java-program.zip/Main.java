import java.util.*;
public class Main{
    public static void main(String args[]){
        Scanner ps = new Scanner(System.in);
        int n = ps.nextInt(),k=1;
        for(int i = 0;i<n;i++){
            for(int j = n;j>i;j--,k++){
                System.out.print(k+" ");
            }
            System.out.println();
        }
        for(int i = 0;i<n;i++){
            for(int j = 0;j<=i;j++,k++){
                System.out.print(k+" ");
            }
            System.out.println();
        }
    }
}