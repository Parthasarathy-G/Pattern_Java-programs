import java.util.Scanner;
public class Main
{            
    public static void main(String[] args){
        Scanner pk = new Scanner(System.in);
        int n = pk.nextInt();
        for (int i = 0; i < n; i++) {
            int number = 1;
            for(int k = i;k<n;k++){
                System.out.print(" ");
            }
            for (int j = 0; j <= i; j++) {
                System.out.printf(number+" ");
                number = number * (i - j) / (j + 1);
            }
            System.out.println();
        }
  
    }
  
}