import java.util.*;
public class Main {    
    public static void main(String args[]){   
    int row,r,c,d ;
    Scanner n = new Scanner(System.in);
    row = n.nextInt();
    d=row-1;
   for(r = 0; r < row; r++) 
    { int k = 1;
        for (c = 0; c < row ; c++)
        { 
            if (r == 0 || r == row - 1 || c == d)
                System.out.print(k+" ");
            else
                System.out.print("  ");
        k++;}
        d--;
        System.out.println();
    }
    }
}
