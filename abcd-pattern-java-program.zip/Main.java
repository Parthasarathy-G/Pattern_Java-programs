import java.util.Scanner;
    
    public class Main
    {
        public static void main(String[] args)
        {
            Scanner scanner = new Scanner(System.in);

            int rows = scanner.nextInt();
            
            int alphabet = 65;
            
            for(int i=0;i<rows;i++)
            {
                for(int j=0;j<rows-i;j++)
                {
                    System.out.print((char)(alphabet+j));
                }
                for(int k=1;k<=i; k++)
                {
                    System.out.print("  ");
                }
                 
                for(int l=rows-i; l>0; l--)
                {
                        System.out.print((char)(alphabet+l-1));
                }
               System.out.println();
            }
        }
    }
