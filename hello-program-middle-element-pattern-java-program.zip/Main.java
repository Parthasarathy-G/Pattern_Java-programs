import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner ps = new Scanner(System.in);
        String s = ps.next();
        String[] s1 = s.split("");
        String s2 = "";
        int k = s1.length / 2;
            for (int i = 0; i < s1.length / 2; i++) {
                for (int j = 0; j <= i; j++) {
                    if (i == 0) {
                        s2 += s1[k];
                        System.out.println(s2);
                    } else {
                        s2 += s1[k];
                        System.out.println(s2);
                    }
                    k++;
                    if(k >= s1.length) {
                        break;
                    }
                }
                if(k >= s1.length) {
                    break;
                }
            }
            for (int i = 0; i < (s1.length / 2); i++) {
                s2 += s1[i];
                System.out.println(s2);
            }
        }
        
    }