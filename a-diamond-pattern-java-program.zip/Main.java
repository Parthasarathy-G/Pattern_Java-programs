import java.util.*;

public class Main
{
  
public static void main (String args[])
  {
    
Scanner sc = new Scanner (System.in);
    
int num = sc.nextInt (), o = 1, m, i = 1, l = 1;
    
char ch = sc.next ().charAt (0);
    
m = i;
    
for (i = 1; i < num; i++)
      {
	
for (int j = num - 1; j >= i; j--)
	  {
	    
System.out.print (" ");
	} 
for (int k = o; k <= m; k++)
	  {
	    
System.out.print (ch);
	  
} m++;
	m++;
	
System.out.println ();
    } 
for (i = 1; i <= num; i++)
      {
	
for (int j = 1; j < i; j++)
	  {
	    
System.out.print (" ");
	} 
for (int k = m; k >= o; k--)
	  {
	    
System.out.print (ch);
	  
} 
m--;
	m--;
	
System.out.println ();

} 
} 
}
