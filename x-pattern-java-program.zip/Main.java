import java.util.*;
public class Main{
    public static void main(String[] args){           
	Scanner n = new Scanner(System.in);
	int num = n.nextInt();	 
              int k=2*(num-1)+1;
	for(int i=1;i<=k;i++)
               {              
	        for(int j=1;j<=k;j++)   
                        {      if(j == i || j == k-i+1)
                               System.out.print("*");
                                System.out.print(" ");          	
                           }
	 System.out.println();
               }            
    }
}
