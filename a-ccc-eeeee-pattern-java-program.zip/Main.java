import java.util.*;
public class Main
{
    public static void main(String[] args)
    {
        Scanner n = new Scanner(System.in);
        int n1 = n.nextInt();
        for (int i = 0; i <= n1+2; i++)
        {
            int alphabet = 65;
            for (int j = n1; j >= i; j--)
            {
                System.out.print(" ");
            }

            for (int k = 0; k <= i; k++)
            {
                System.out.print((char) (alphabet + i) + " ");
         }i++;
            System.out.println();
       }
    }
}

